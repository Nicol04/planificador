<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista Previa - {{ $sesion->titulo }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }

            body {
                margin: 0;
            }
        }

        .document-preview {
            max-width: {{ $orientacion === 'horizontal' ? '1000px' : '800px' }};
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            min-height: 100vh;
        }

        .document-header {
            border-bottom: 3px solid #0066cc;
            padding: 20px;
            text-align: center;
        }

        .logos-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .logo-placeholder {
            width: 80px;
            height: 80px;
            border: 2px dashed #ccc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            text-align: center;
            color: #666;
        }

        .document-title {
            color: #0066cc;
            font-weight: bold;
            font-size: 24px;
            margin: 10px 0;
        }

        .section-title {
            background: #0066cc;
            color: white;
            padding: 10px 15px;
            margin: 20px 0 10px 0;
            font-weight: bold;
            border-radius: 5px;
        }

        .info-table {
            border: 1px solid #ddd;
            width: 100%;
            margin-bottom: 20px;
        }

        .info-table td,
        .info-table th {
            border: 1px solid #ddd;
            padding: 8px;
            vertical-align: top;
        }

        .info-table th {
            background: #f8f9fa;
            font-weight: bold;
        }

        .content-text {
            text-align: justify;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .enfoques-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .enfoques-table th {
            background: #0066cc;
            color: white;
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .enfoques-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: center;
        }

        .floating-buttons {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }

        .btn-floating {
            margin-bottom: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            display: block;
            width: 150px;
        }

        .table {
            border: 1px solid #ddd;
            margin-bottom: 20px;
            border-collapse: collapse;
            table-layout: fixed;
            width: 100%;
        }

        .table th,
        .table td {
            padding: 6px 8px;
            /* reducir padding para evitar "espacios" grandes */
            vertical-align: top;
            border: 1px solid #ddd;
            font-size: 12px;
            line-height: 1.35;
            /* menos espacio vertical */
            word-break: break-word;
            white-space: normal;
            /* permitir ajuste */
        }

        .table .bg-light {
            background-color: #f8f9fa !important;
        }

        .table .fw-bold {
            font-weight: bold;
        }

        .table .text-primary {
            color: #0066cc !important;
        }

        .badge {
            font-size: 10px;
            padding: 3px 6px;
        }

        /* Estilo específico para la etiqueta ESTÁNDARES */
        .label-estandares {
            background: #f0f7ff;
            /* tono suave */
            color: #003366;
            /* color destacado */
            font-weight: 700;
            font-size: 13px;
            padding: 8px 10px;
            text-align: left;
            width: 18%;
            /* ocupa menos espacio */
            white-space: nowrap;
        }

        .estandares-valor {
            padding: 6px 10px;
            font-size: 12px;
            line-height: 1.4;
        }

        .estandares-valor .est-item {
            margin: 0 0 4px 0;
            /* espacio pequeño entre entradas */
            display: block;
        }

        .table .table-dark {
            background: #0066cc !important;
            color: #fff !important;
            font-weight: 700;
            font-size: 12px;
            text-align: center;
        }

        .table td.small {
            font-size: 11px;
        }
    </style>
</head>

<body class="bg-light">

    <!-- Botones flotantes -->
    <div class="floating-buttons no-print">
        <button class="btn btn-success btn-floating" onclick="descargarDocumento()">
            <i class="fas fa-download"></i> Descargar Word
        </button>
        <button class="btn btn-info btn-floating" onclick="window.print()">
            <i class="fas fa-print"></i> Imprimir
        </button>
        <button class="btn btn-secondary btn-floating" onclick="cerrarVentana()">
            <i class="fas fa-arrow-left"></i> Volver
        </button>
    </div>

    <div class="document-preview">
        <!-- Header con logos -->
        <div class="document-header">
            <div class="logos-container">
                <!-- Logo Institución (Izquierda) -->
                <div class="logo-container" style="width: 80px; height: 80px;">
                    <img src="{{ url('assets/img/logo_colegio.png') }}" alt="Logo Institución"
                        style="width: 80px; height: 80px; object-fit: contain;">
                </div>

                <!-- Contenido Central -->
                <div class="text-center flex-grow-1">
                    <div class="document-title">SESIÓN DE APRENDIZAJE</div>
                    <h3 style="color: #0066cc;">"{{ $sesion->titulo }}"</h3>
                    <h5 style="color: #0066cc;">{{ date('Y') }}</h5>
                </div>

            </div>
        </div>

        <div class="p-4">
            <!-- 1. DATOS INFORMATIVOS -->
            <div class="section-title">1. DATOS INFORMATIVOS:</div>

            <table class="info-table">
                <tr>
                    <th style="width: 40%;">1.1. Institución educativa:</th>
                    <td>Ann Goulden</td>
                </tr>
                <tr>
                    <th>1.2. Directora:</th>
                    <td>Maricarmen Juliana Ruiz Falero</td>
                </tr>
                <tr>
                    <th>1.3. Docente:</th>
                    <td>{{ $sesion->docente ? trim(($sesion->docente->persona->nombre ?? '') . ' ' . ($sesion->docente->persona->apellido ?? '')) : 'No asignado' }}
                    </td>
                </tr>
                <tr>
                    <th>1.4. Grado y sección:</th>
                    <td>{{ $sesion->aulaCurso && $sesion->aulaCurso->aula ? $sesion->aulaCurso->aula->grado_seccion : 'No asignado' }}
                    </td>
                </tr>
                <tr>
                    <th>1.5. Área:</th>
                    <td>{{ $sesion->aulaCurso && $sesion->aulaCurso->curso ? $sesion->aulaCurso->curso->curso : 'No asignado' }}
                    </td>
                </tr>
                <tr>
                    <th>1.6. Fecha:</th>
                    <td>{{ $sesion->fecha ? \Carbon\Carbon::parse($sesion->fecha)->format('d/m/Y') : 'No asignado' }}
                    </td>
                </tr>
                <tr>
                    <th>1.7. Tiempo:</th>
                    <td>{{ $sesion->tiempo_estimado ?? 'No asignado' }} minutos</td>
                </tr>
            </table>
            <!-- 2. NOMBRE DE LA SESIÓN -->
            <div class="section-title">2. NOMBRE DE LA SESIÓN:</div>
            <div class="content-text fw-bold" style="font-size: 18px; color: #0066cc;">
                {{ $sesion->titulo }}
            </div>

            <!-- 3. PROPÓSITO DE LA SESIÓN -->
            <div class="section-title">3. PROPÓSITO DE LA SESIÓN:</div>
            <div class="content-text">
                {{ $sesion->proposito_sesion ?? 'No especificado' }}
            </div>

            <!-- 3. PROPÓSITOS DE APRENDIZAJE -->
            <!-- 3. PROPÓSITOS DE APRENDIZAJE -->
            <div class="section-title">3. PROPÓSITOS DE APRENDIZAJE:</div>

            <table class="table table-bordered table-striped">
                <tbody>
                    @if (!empty($sesionInfo['propositos']) && count($sesionInfo['propositos']) > 0)
                        @foreach ($sesionInfo['propositos'] as $proposito)
                            <!-- FILA 1: ESTÁNDARES (dos columnas: etiqueta | valor) -->
                            <tr>
                                <th class="label-estandares" colspan="1">ESTÁNDARES</th>
                                <td class="estandares-valor" colspan="3">
                                    @if (!empty($proposito['estandares']) && is_array($proposito['estandares']))
                                        @foreach ($proposito['estandares'] as $est)
                                            <span class="est-item small">{{ $est }}</span>
                                        @endforeach
                                    @elseif (!empty($proposito['estandares']))
                                        <span class="est-item small">{{ $proposito['estandares'] }}</span>
                                    @else
                                        <span class="text-muted small">No especificado</span>
                                    @endif
                                </td>
                            </tr>

                            <!-- FILA 2: ENCABEZADOS 4 COLUMNAS -->
                            <tr>
                                <th class="table-dark" style="width:25%;">COMPETENCIA / CAPACIDADES</th>
                                <th class="table-dark" style="width:25%;">CRITERIOS DE EVALUACIÓN</th>
                                <th class="table-dark" style="width:25%;">EVIDENCIAS</th>
                                <th class="table-dark" style="width:25%;">INSTRUMENTOS</th>
                            </tr>

                            <!-- FILA 3: CONTENIDO en 4 columnas -->
                            <tr>
                                <!-- Competencia / Capacidades -->
                                <td style="white-space: normal;">
                                    <div class="fw-bold text-primary mb-1" style="font-size: 12px;">
                                        {{ $proposito['competencia'] ?? 'No especificado' }}
                                    </div>
                                    @if (!empty($proposito['capacidades']))
                                        <ul class="mb-0" style="padding-left:18px; margin:0;">
                                            @foreach ($proposito['capacidades'] as $cap)
                                                <li class="small text-muted" style="margin-bottom:4px;">
                                                    {{ $cap }}</li>
                                            @endforeach
                                        </ul>
                                    @else
                                        <span class="text-muted small">No especificado</span>
                                    @endif
                                </td>

                                <!-- Criterios de evaluación -->
                                <td class="small" style="white-space: normal;">
                                    @php $criterios = $proposito['criterios'] ?? null; @endphp
                                    @if (is_array($criterios) && !empty($criterios))
                                        <ul class="mb-0" style="padding-left:18px; margin:0;">
                                            @foreach ($criterios as $c)
                                                <li style="margin-bottom:4px;">{{ $c }}</li>
                                            @endforeach
                                        </ul>
                                    @elseif (!empty($criterios) || $criterios === '0')
                                        {!! nl2br(e((string) $criterios)) !!}
                                    @else
                                        <span class="text-muted small">No especificado</span>
                                    @endif
                                </td>

                                <!-- Evidencias -->
                                <td class="small" style="white-space: normal;">
                                    @php $evid = $proposito['evidencia'] ?? ($sesion->detalle?->evidencia ?? null); @endphp
                                    @if (!empty($evid) || $evid === '0')
                                        {!! nl2br(e((string) $evid)) !!}
                                    @else
                                        <span class="text-muted small">No especificado</span>
                                    @endif
                                </td>

                                <!-- Instrumentos -->
                                <td class="small" style="white-space: normal;">
                                    @if (!empty($proposito['instrumentos']) && is_array($proposito['instrumentos']))
                                        @foreach ($proposito['instrumentos'] as $inst)
                                            <span
                                                class="badge bg-secondary small d-block mb-1">{{ $inst }}</span>
                                        @endforeach
                                    @elseif (!empty($proposito['instrumentos']))
                                        <span class="badge bg-secondary small">{{ $proposito['instrumentos'] }}</span>
                                    @else
                                        <span class="text-muted small">No especificado</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="4">
                                <div class="content-text">No se han definido propósitos de aprendizaje para esta sesión.
                                </div>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>

            <!-- 4. ENFOQUES TRANSVERSALES -->
            @if (!empty($sesion->detalle?->transversalidad))
            <div class="section-title">4. ENFOQUES TRANSVERSALES</div>

            <table class="table table-bordered">
                <tr>
                    <th style="background:#e3f2fd; color:#0066cc;" colspan="4">
                        <i class="fas fa-lightbulb"></i>
                        Enfoques transversales:
                        <span class="fw-bold">{{ implode(', ', $enfoquesTransversales ?? []) }}</span>
                    </th>
                </tr>
                <tr>
                    <th style="width: 25%;">Competencias y capacidades</th>
                    <th style="width: 25%;">Desempeños</th>
                    <th style="width: 25%;">Criterios</th>
                    <th style="width: 25%;">Instrumento de evaluación</th>
                </tr>
                <tr>
                    <td>
                        <div class="mb-2">
                            <span class="fw-bold">
                                @if (!empty($competenciasTransversales))
                                    <ul class="mb-1">
                                        @foreach ($competenciasTransversales as $comp)
                                            <li>{{ $comp }}</li>
                                        @endforeach
                                    </ul>
                                @else
                                    <span class="text-muted">No especificado</span>
                                @endif
                            </span>
                        </div>
                        <div>
                            @if (!empty($capacidadesTransversales))
                                <ul>
                                    @foreach ($capacidadesTransversales as $cap)
                                        <li>{{ $cap }}</li>
                                    @endforeach
                                </ul>
                            @else
                                <span class="text-muted">No especificado</span>
                            @endif
                        </div>
                    </td>
                    <td>
                        @if (!empty($desempenosTransversales))
                            <ul>
                                @foreach ($desempenosTransversales as $des)
                                    <li>{{ $des }}</li>
                                @endforeach
                            </ul>
                        @else
                            <span class="text-muted">No especificado</span>
                        @endif
                    </td>
                    <td>
                        {{ $criteriosTransversales ?? 'No especificado' }}
                    </td>
                    <td>
                        @if (!empty($instrumentosTransversales))
                            <ul>
                                @foreach ($instrumentosTransversales as $inst)
                                    <li>{{ $inst }}</li>
                                @endforeach
                            </ul>
                        @else
                            <span class="text-muted">No especificado</span>
                        @endif
                    </td>
                </tr>
            </table>
            @endif

            <!-- MOMENTOS: tabla simple -->
            <div class="section-title">MOMENTOS Y ESTRATEGIAS</div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width:20%;">MOMENTOS</th>
                        <th>ESTRATEGIAS</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="fw-bold">INICIO</td>
                        <td>{!! $inicioHtml ?? '<span class="text-muted small">No especificado</span>' !!}</td>
                    </tr>
                    <tr>
                        <td class="fw-bold">DESARROLLO</td>
                        <td>{!! $desarrolloHtml ?? '<span class="text-muted small">No especificado</span>' !!}</td>
                    </tr>
                    <tr>
                        <td class="fw-bold">CIERRE</td>
                        <td>{!! $cierreHtml ?? '<span class="text-muted small">No especificado</span>' !!}</td>
                    </tr>
                </tbody>
            </table>

            @php
                $docenteNombre = $sesion->docente ? trim(($sesion->docente->persona->nombre ?? '') . ' ' . ($sesion->docente->persona->apellido ?? '')) : null;
            @endphp
            <div class="mt-4" style="margin-top:24px;">
                <div style="width:260px; margin:40px auto 0; text-align:center;">
                    <div style="border-bottom:1px solid #000; height:44px;"></div>
                    <div class="small text-muted mt-2">Firma del docente</div>
                    <div class="fst-italic mt-2">{{ $docenteNombre ?? '_________________________' }}</div>
                </div>
            </div>

        </div>
    </div>

    <script>
        function descargarDocumento() {
            const orientacion = '{{ $orientacion }}';
            window.location.href = `/sesiones/{{ $sesion->id }}/previsualizar?orientacion=${orientacion}`;
        }

        function cerrarVentana() {
            // Primero intentar cerrar si es popup
            if (window.opener !== null && !window.opener.closed) {
                window.close();
                return;
            }

            // Si hay historial, ir atrás
            if (window.history.length > 1) {
                window.history.back();
            } else {
                // Si no hay historial, ir a la lista de sesiones
                window.location.href = '/docente/sesions';
            }
        }

        // Detectar teclas para navegación
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                cerrarVentana();
            }
            // Alt + Flecha izquierda para volver
            if (event.altKey && event.key === 'ArrowLeft') {
                cerrarVentana();
            }
        });

        // Mostrar un toast de ayuda al cargar
        window.addEventListener('load', function() {
            setTimeout(function() {
                const helpDiv = document.createElement('div');
                helpDiv.innerHTML = `
            <div style="position: fixed; bottom: 20px; left: 20px; background: #333; color: white; 
                 padding: 10px 15px; border-radius: 5px; font-size: 12px; z-index: 1001;" 
                 id="helpToast">
                <i class="fas fa-info-circle"></i> Presiona <kbd>ESC</kbd> o <kbd>Alt + ←</kbd> para volver a sesiones
            </div>
        `;
                document.body.appendChild(helpDiv);

                // Ocultar después de 3 segundos
                setTimeout(function() {
                    const toast = document.getElementById('helpToast');
                    if (toast) {
                        toast.style.opacity = '0';
                        toast.style.transition = 'opacity 0.5s';
                        setTimeout(() => toast.remove(), 500);
                    }
                }, 3000);
            }, 1000);
        });

        function abrirVistaPreviaSesion(orientacion) {
            if (sesionIdActual) {
                const url = `/sesiones/${sesionIdActual}/vista-previa?orientacion=${orientacion}`;
                window.open(url, 'vistaPreviaSesion', 'width=1200,height=800,scrollbars=yes,resizable=yes');
                cerrarModalPreviaSesion();
            }
        }
    </script>

</body>

</html>
